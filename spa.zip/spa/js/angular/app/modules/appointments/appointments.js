  appointmentsModule = angular.module('appointmentsModule', []);

  appointmentsModule.run(function(dataService) {
    var confObj = {};
    confObj.moduleName = "Appointments";
    confObj.basePath = "/#/appointments";
    confObj.appointmentViewPath = "/#/appointments/appointment_view";
    confObj.moduleColor = "#FFE4E1";
    appointmentsModule.confObj = confObj;
    dataService.moduleList.push(confObj);
  });

  app.controller('AppointmentsController', function ($scope, $timeout, dataService) {
    $scope.dataService = dataService;
    $scope.name = "Appointments";
    $scope.appointments = appointmentsMockedData;

    $scope.initAppointment = function() {
      if($scope.dataService.currentAppointment != null && $scope.dataService.currentAppointment.isNew) {
        console.log("booking new appointment..");
      }
    }

    $scope.bookAppointment = function() {
      delete $scope.dataService.currentAppointment.isNew;
      $scope.dataService.currentAppointment.date = new Date().toString();
      $scope.dataService.currentAppointment.time = "10 am";
      $scope.appointments.push($scope.dataService.currentAppointment);
      location = appointmentsModule.confObj.basePath;
    }

    $scope.viewAppointment = function() {
      $scope.dataService.currentAppointment = this.appointment;
      location = appointmentsModule.confObj.appointmentViewPath;
    }

    $scope.viewProvider = function() { //context switch
      $scope.dataService.currentProvider = $scope.dataService.currentAppointment.provider;
      var providersModuleDefinition = dataService.getModuleDefinition('providers');
      location = providersModuleDefinition.providerViewPath;
    }
  });