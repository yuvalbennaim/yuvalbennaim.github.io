  providersModule = angular.module('providersModule', []);

  providersModule.run(function(dataService) {
    var confObj = {};
    confObj.moduleName = "Providers";
    confObj.basePath = "/#/providers";
    confObj.moduleColor = "#B9E4EC";    
    confObj.providerViewPath = "/#/providers/provider_view";
    providersModule.confObj = confObj;
    dataService.moduleList.push(confObj);
  });

  app.controller('ProvidersController', function ($scope, dataService) {
    $scope.dataService = dataService;
    $scope.name = "Providers";
    $scope.providers = providersMockedData;

    $scope.viewProvider = function() {
      $scope.dataService.currentProvider = this.provider;
      location = providersModule.confObj.providerViewPath;
    }

    $scope.viewExistingAppointment = function() {
      //todo
    }

    $scope.scheduleAppointment = function() { //context switch
      var newAppointment = {"name" : "My NEW Appointment with " + $scope.dataService.currentProvider.prefix + " " + $scope.dataService.currentProvider.name};
      newAppointment.provider = $scope.dataService.currentProvider;
      newAppointment.isNew = true;
      $scope.dataService.currentAppointment = newAppointment;
      var appointmentsModuleDefinition = dataService.getModuleDefinition('appointments');
      location = appointmentsModuleDefinition.appointmentViewPath;
    }
});