  
  app = angular.module('appMain', ['ngResource', 'ngRoute', 'ngAnimate', 'directives', 'providersModule', 'appointmentsModule']);
  //app = angular.module('appMain', ['ngResource', 'ngRoute', 'ngAnimate', 'directives', 'providersModule']);
  //app = angular.module('appMain', ['ngResource', 'ngRoute', 'ngAnimate', 'directives', 'appointmentsModule']);
  
  app.service('dataService', function() {
    var dataService = {};
    dataService.search = "";
    dataService.transitionClass = "view-animate-forward";
    dataService.moduleList = [];
    dataService.currentModule;
    dataService.currentAppointment;
    dataService.currentProvider;

    dataService.getModuleDefinition = function(name) {
      for(var m = 0; m < dataService.moduleList.length; m++) {
        if(dataService.moduleList[m].moduleName.toLowerCase() == name.toLowerCase()) {
          return dataService.moduleList[m];
        }
      }

      return null;
    }

    dataService.hasModuleLoaded = function(name) {
      for(var m = 0; m < dataService.moduleList.length; m++) {
        if(dataService.moduleList[m].moduleName.toLowerCase() == name.toLowerCase()) {
          return true;
        }
      }

      return false;
    }

    dataService.getModuleStyle = function(name, target) {
      if(name != null) {
        var moduleDefinition = dataService.getModuleDefinition(name);

        if(moduleDefinition != null) {
          if(target == "a") {
            return {"background" : moduleDefinition.moduleColor};
          }
          else if(target == "header") {
            return {"color" : moduleDefinition.moduleColor};
          }
          else if(target == "view") {
            return {"background" : moduleDefinition.moduleColor, "height" : "100%"}; 
          }
        }
        else {
          return null;
        }
      }
      else {
        return null;
      }
    }

    return dataService;
  });


  app.config(function ($routeProvider) {
    $routeProvider
      .when('/:module/:page', {templateUrl: function(params) {
          var basePath = "/js/angular/app/modules/" + params.module.toLowerCase() + "/";
          var path = basePath + params.page.toLowerCase() + ".html";
          return path;
        }
      })
      .when('/:module', {templateUrl: function(params) {
          if(params.module.toLowerCase() == "home") {
            return "/home.html";
          }
          else {
            var basePath = "/js/angular/app/modules/" + params.module.toLowerCase() + "/";
            var path = basePath + params.module.toLowerCase() + ".html";
            return path;
          }
        }
      })
      .otherwise({redirectTo: '/home'});
  }); 


  app.run(function(dataService) {
    var confObj = {};
    confObj.moduleName = "Home";
    confObj.basePath = "/#/home";
    confObj.moduleColor = "#eee";  
    dataService.moduleList.unshift(confObj);
  });


  app.controller('RouteController', function ($scope, $location, $timeout, dataService) {
    $scope.dataService = dataService;
    $scope.dataService.currentPage = "";

    $scope.init = function() {
      dataService.viewReady = true;
    }
    
    $scope.$on('$locationChangeStart', function(event, next, current) { 
      var path = $location.path();
      console.log("Route " + path+ " requested");  
    });
    
    $scope.$on('$routeChangeError', function (event, args) {
      var path = $location.path();
      console.log("Route " + path + " not found !");
    });

    $scope.$on('$locationChangeSuccess', function () {
      var path = $location.path();
      path = path.substring(1, path.length);
      console.log("route Loaded: " + path);

      var module = path.split("/")[0];

      if(module != dataService.currentModule) { //context switch
        $timeout(function() {
          dataService.transitionClass = (dataService.transitionClass  == "view-animate-forward") ? "view-animate-backward" : "view-animate-forward";
        }, 100);
      }

      dataService.currentModule = module;

      if(module == "home") {
        dataService.currentAppointment = null;
        dataService.currentProvider = null;
      }
    });
  });


  
 