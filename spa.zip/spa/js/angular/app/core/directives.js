
directives = angular.module('directives', []);

directives.directive("ybBubbles", function() {
  return {
    replace: false,
    restrict: "EA",
    template: '<canvas ng-init="init()" width="{{width}}" height="{{height}}" style="position: absolute; top:0; left:0; right:0; bottom:0"/>',

    scope: {
      width: "@width",
      height: "@height",
      count: "=count"
    },

    link: function($scope, element, attrs) {
      $scope.element = element;
      $scope.attrs = attrs;
      $scope.bubbles = 10;
      $scope.globalAlpha = .5;
      $scope.animate = true;
    },

    controller: function($scope, $timeout, dataService) {   
      $scope.dataService = dataService;

      $scope.init = function() {
        $timeout(function() {
          $scope.setCanvasDimensions();
          $scope.initializeBubbles();

          $scope.$watch('count', function(newValue, oldValue) {
            console.log("count changed..." + $scope.count);
            $scope.initializeBubbles();
          });

          $scope.$watch('animate', function(newValue, oldValue) {
            if($scope.animate == true) {
              $scope.setCanvasDimensions();
              $scope.draw();
            }
          });
        });
        
        $(window).resize(function() {
          $scope.setCanvasDimensions();
        });       
      };
      
      $scope.setCanvasDimensions = function() {
        if($scope.canvas == null) {
          $scope.canvas = $scope.element.find('canvas')[0];
        }
        
        $scope.canvas.width = window.innerWidth;
        $scope.canvas.height = window.innerHeight;
        $scope.w = $scope.canvas.width;
        $scope.h = $scope.canvas.height; 
        $scope.center = {"x" : $scope.w/2, "y" : $scope.h/2}; 
      }

      $scope.initializeBubbles = function() {
        $scope.bubbles = [];

        for(var b = 0; b < $scope.count; b++) {
          $scope.bubbles.push(new $scope.createBubble(b));
        }
      }
         
      $scope.createBubble = function(i) {
        this.id = "bubble _" + i;

        this.create = function() {
          this.x = parseInt(Math.random() * $scope.w);
          this.y = parseInt(Math.random() * $scope.h);
          var maxer = Math.max($scope.w, $scope.h);
          var r = parseInt(Math.random() * 255);
          var g = parseInt(Math.random() * 255);
          var b = parseInt(Math.random() * 255);
          this.radius = 1;
          this.alpha = $scope.globalAlpha;
          this.vr = Math.max(2, parseInt(Math.random() * 10));
          this.maxRadius = Math.max(maxer/4, parseInt(Math.random() * maxer));
          this.frames = parseInt(this.maxRadius / this.vr);
          this.color = "rgb("+r+", "+g+", "+b+")"; 
          this.frames = this.maxRadius / this.vr;
          this.alphaDecay = (this.alpha / this.frames);

          var bub = this;
          var imageObj = new Image();

          imageObj.onload = function() {
            bub.img = imageObj;
          };

          imageObj.src = '/images/logo.png';
        }

        this.create();

        this.rebirth = function() {   
          this.create();
        }

        this.drawMe = function(ctx) {
          if(this.alpha <= 0 || this.radius >= this.maxRadius) {
            this.rebirth(ctx);
          }
          else {
            var alpha = this.alpha;

            ctx.globalAlpha = alpha; 

            // ctx.fillStyle = this.color; //gradient; 
            // ctx.beginPath();
            // ctx.arc(this.x, this.y, this.radius, 0, 2 * Math.PI, false);
            // ctx.fill();
            // ctx.lineWidth = 1;
            // ctx.strokeStyle = '#fff';
            // ctx.stroke();

            // var gradient = ctx.createRadialGradient(this.x, this.y, this.radius/2, this.x, this.y, this.radius);
            // gradient.addColorStop(0, this.color);
            // gradient.addColorStop(1, 'white');
            // ctx.fillStyle = gradient; 
            // ctx.fill();

            if(this.img != undefined) {
              ctx.drawImage(this.img, this.x - this.radius/2, this.y - this.radius/2, this.radius, this.radius);
            }

            this.radius += this.vr; 
            this.alpha -= this.alphaDecay;
          }    
        };
      }

      $scope.drawBubbles = function() {
        var ctx = $scope.ctx;
        var center = $scope.center;
        ctx.globalAlpha = 0.1;

        for(var p = 0; p < $scope.bubbles.length; p++) {
          var bubble = $scope.bubbles[p];
          bubble.drawMe(ctx);          
        }
      }

      $scope.draw = function() {
        if($scope.canvas != null && $scope.animate) {
          $scope.ctx = $scope.canvas.getContext("2d");                 
          $scope.ctx.clearRect(0, 0, $scope.w, $scope.h);          
          $scope.drawBubbles();
          $timeout($scope.draw, 50);
        }
      }
    }
  }
});
