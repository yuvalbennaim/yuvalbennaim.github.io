
var app = angular.module('AppModule', ['ngResource', 'ngRoute', 'ngAnimate', 'directives']);


//////////////////////  SERVICES  //////////////////////////////////////

app.service('dataService', function() {
  var dataService = {};
  dataService.viewReady = false;
  dataService.loading = false;
  dataService.showCards = false;
  dataService.loginReady = false;
  dataService.transitionClass = "";
  return dataService;
});


app.config(function ($routeProvider) {
  $routeProvider
    .when('/:page', {templateUrl: function(params) {
        return params.page + ".html";
      }
    })
    
    .otherwise({redirectTo: '/splash'});
}); 


//////////////////////  ROUTE CONTROLLER  ////////////////////////////////////// 


app.controller("RouteController", function RouteController($rootScope, $scope, $location, $timeout, dataService) {
  $scope.dataService = dataService;
  dataService.loading = false;

  $scope.$on('$locationChangeStart', function(event, next, current) { 
    var path = $location.path();
    path = path.substring(1, path.length); 
    console.log("locationChangeStart " + path);  
  });
  
  $scope.$on('$routeChangeError', function (event, args) {
    var path = $location.path();
    path = path.substring(1, path.length);
    console.log("routeChangeError " + path + " not found !");
  });

  $scope.$on('locationChangeSuccess', function (event, args) {
    var path = $location.path();
    path = path.substring(1, path.length);
    console.log("locationChangeSuccess: " + path);
  });
});



///////////////////////  RESUME CONTROLLER //////////////////////////////////////


app.controller("LoginCtrl", function ($scope, dataService, $timeout, dataService, helperService) {

  $scope.init = function() {
    dataService.loginReady = false;

    $timeout(function () {
      dataService.loginReady = true;
    }, 5000);
  }


  $scope.login = function() {
    dataService.viewReady = false;
    dataService.transitionClass = "view-animate-forward";
    dataService.viewReady = true;
    top.location = "#/summary";
  }

  $scope.goForward = function() {
    dataService.transitionClass = "view-animate-forward";
    dataService.viewReady = false;
    dataService.showCards = false;
    dataService.loginReady = false;

    $timeout(function () {
      top.location = "#/summary";
    });
  }
});




app.controller("SummaryCtrl", function ($scope, dataService, $timeout, dataService) {
  $scope.criticalColor = "rgba(255, 0, 0, 0.33)";
  $scope.badColor = "rgba(255, 165, 0, 0.33)";
  $scope.neutralColor = "rgba(255, 255, 0, 0.33)";
  $scope.goodColor = "rgba(0, 255, 0, 0.33)";

  $scope.showViews = [];
  $scope.views = [
    {"name" : "West", "color" : "#7AA6D2", "value" : "20", "notes": [
      {"title" : "Santa Monica Outage", "description" : "Main line rupture due to construction in the area", "catagory" : "critical"},
      {"title" : "Santa Monica Outage", "description" : "Main line rupture due to construction in the area", "catagory" : "critical"},
      {"title" : "Santa Monica Outage", "description" : "Main line rupture due to construction in the area", "catagory" : "bad"},
            {"title" : "Santa Monica Outage", "description" : "Main line rupture due to construction in the area", "catagory" : "bad"},
      {"title" : "Santa Monica Outage", "description" : "Main line rupture due to construction in the area", "catagory" : "neutral"},
      {"title" : "Santa Monica Outage", "description" : "Main line rupture due to construction in the area", "catagory" : "neutral"},
      {"title" : "Los Angeles", "description" : "Everyting looks good with the network migration", "catagory" : "good"}
      ]},
    {"name" : "Central", "color" : "#C26FA1", "value" : "75", "notes": [
      {"title" : "Santa Monica Outage", "description" : "Main line rupture due to construction in the area", "catagory" : "good"},
      {"title" : "Santa Monica Outage", "description" : "Main line rupture due to construction in the area", "catagory" : "good"},
      {"title" : "Los Angeles", "description" : "Everyting looks good with the network migration", "catagory" : "good"}
      ]}, 
    {"name" : "North East", "color" : "#C26F6F", "value" : "50", "notes": [
      {"title" : "Santa Monica Outage", "description" : "Main line rupture due to construction in the area", "catagory" : "bad"},
      {"title" : "Santa Monica Outage", "description" : "Main line rupture due to construction in the area", "catagory" : "neutral"},
      {"title" : "Santa Monica Outage", "description" : "Main line rupture due to construction in the area", "catagory" : "good"},
      {"title" : "Los Angeles", "description" : "Everyting looks good with the network migration", "catagory" : "good"}
      ]}
  ];

  $scope.init = function() {
    dataService.viewReady = true;
    dataService.showCards = false;

    $scope.showViews["West"] = true;
    $scope.showViews["Central"] = true;
    $scope.showViews["East"] = true;

    $timeout(function () {
      dataService.loading = true;
    }, 1000);

    $timeout(function () {
      dataService.showCards = true;
      dataService.loading = false;
    }, 5000);
  }

  

  $scope.toShowCard = function(name) {
    return $scope.showViews[name];
  }

  $scope.showMoreInfo = function() {
    $scope.dataService.showCards = false;
  }

  $scope.hideCard = function(name) {
    $scope.showViews[name] = false;
  }

  $scope.showCard = function(name) {
    $scope.showViews[name] = true;
  }

  $scope.getNoteStyle = function() {
    var note = this.note;
    var bg;

    if(note.catagory == "critical") {
      bg = $scope.criticalColor;
    }
    else if(note.catagory == "bad") {
      bg = $scope.badColor;
    }
    else if(note.catagory == "neutral") {
      bg = $scope.neutralColor;
    }
    else if(note.catagory == "good") {
      bg = $scope.goodColor;
    }
    else {
      return null;
    }

    return {"background-color" :  bg};
  }

  $scope.goBack = function() {
    dataService.showCards = false;
    dataService.transitionClass = "view-animate-backward";
    
    $timeout(function () {

      $timeout(function () {
        dataService.viewReady = false;
      }, 100);

      top.location = "#/splash";
    });
  }
});
